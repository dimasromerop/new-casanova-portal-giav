<?php
// Silence is golden to prevent directory listing
