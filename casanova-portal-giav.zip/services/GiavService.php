<?php
namespace NewCasanovaPortalGiav\Services;

class GiavService
{
    public function getInfo(): array
    {
        return ['service' => 'GiavService', 'status' => 'ready'];
    }
}
