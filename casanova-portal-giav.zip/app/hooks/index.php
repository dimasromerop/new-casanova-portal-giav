<?php
// Custom hooks placeholder for the app/hooks directory.
// Silence is golden to prevent directory listing.
