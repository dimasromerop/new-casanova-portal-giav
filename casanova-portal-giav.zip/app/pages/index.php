<?php
// Page components placeholder for the app/pages directory.
// Silence is golden to prevent directory listing.
