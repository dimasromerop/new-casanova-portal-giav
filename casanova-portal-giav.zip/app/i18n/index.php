<?php
// i18n placeholder for translation files.
// Silence is golden to prevent directory listing.
