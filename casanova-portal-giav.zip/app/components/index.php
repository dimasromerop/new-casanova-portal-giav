<?php
// Shared UI components placeholder for the app/components directory.
// Silence is golden to prevent directory listing.
