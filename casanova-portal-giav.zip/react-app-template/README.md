# React App Template (Casanova Portal)

Plantilla mínima para compilar la SPA del portal.

- App: `src/App.jsx`
- Output esperado en el plugin:
  - `assets/portal-app.js`
  - `assets/portal-app.css` (opcional)

## Modo mock

`?mock=1` (solo admin) lee fixtures:
- `includes/mock/dashboard.json`
- `includes/mock/messages.json`
